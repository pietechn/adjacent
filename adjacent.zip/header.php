<header class="header">
<div class="primary-header">
<div class="container">
<div class="primary-header-inner">
<div class="header-logo">
<a href="index.php"><img src="img/logo.png" width="100" height="50" alt="Indico"></a>
</div>
<div class="header-menu-wrap">
<ul class="dl-menu">
<li><a href="index.php">Home</a></li>
<li><a href="about-us.php">About</a></li>
<li><a href="service.php">Services</a></li>
<li><a href="projects.php">Our Projects</a></li>
<li><a href="contact.php">Contact Us</a></li>
<ul>
</div>
<div class="header-right">
<div class="mobile-menu-icon">
<div class="burger-menu">
<div class="line-menu line-half first-line"></div>
<div class="line-menu"></div>
<div class="line-menu line-half last-line"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</header>